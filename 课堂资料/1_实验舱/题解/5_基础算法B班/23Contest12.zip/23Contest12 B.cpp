#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef long long ll;
typedef pair<ll,ll> pii;
const ll maxn = 1010;
const ll INF = 2147483647;
const ll mod = 998244353;
int n, m, val[maxn][maxn], stA[maxn][maxn], edA[maxn][maxn], stB[maxn][maxn], edB[maxn][maxn];
int main(){
	ios::sync_with_stdio(false);
	cin >> n >> m;
	memset(stA, 0x3f, sizeof(stA));
	memset(edA, 0x3f, sizeof(edA));
	memset(stB, 0x3f, sizeof(stB));
	memset(edB, 0x3f, sizeof(edB));
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			cin >> val[i][j];
			stA[i][j] = stB[i][j] = edA[i][j] = edB[i][j] = 0;
		}
	}
	stA[1][1] = val[1][1];
	stB[n][1] = val[n][1];
	edA[n][m] = val[n][m];
	edB[1][m] = val[1][m];
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			if(i == 1 && j == 1) continue;
			stA[i][j] = min(stA[i - 1][j], stA[i][j - 1]) + val[i][j];
		}
		for(int j = m; j >= 1; j--){
			if(i == 1 && j == m) continue;
			edB[i][j] = min(edB[i - 1][j], edB[i][j + 1]) + val[i][j];
		}
	}
	for(int i = n; i >= 1; i--){
		for(int j = 1; j <= m; j++){
			if(i == n && j == 1) continue;
			stB[i][j] = min(stB[i + 1][j], stB[i][j - 1]) + val[i][j];
		}
		for(int j = m; j >= 1; j--){
			if(i == n && j == m) continue;
			edA[i][j] = min(edA[i + 1][j], edA[i][j + 1]) + val[i][j];
		}
	}
	int res = INF;
	for(int i = 2; i < n; i++){
		for(int j = 2; j < m; j++){
			res = min(res, min(stA[i - 1][j] + edA[i + 1][j] + stB[i][j - 1] + edB[i][j + 1],
							   stA[i][j - 1] + edA[i][j + 1] + stB[i + 1][j] + edB[i - 1][j]));
		}
	}
	cout << res;
	return 0;
}