#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef long long ll;
typedef pair<ll,ll> pii;
const ll maxn = 1010;
const ll INF = 2147483647;
const ll mod = 998244353;
int n, k, res, dp[maxn][maxn];
bool vis[maxn];
pair<int,int> a[maxn];
void dfs(int pos){
	vis[pos] = 1;
	dp[pos][0] = 1;
	for(int j = 1; j <= n; j++){
		if(pos == j) continue;
		if(a[j].fi > a[pos].fi || a[j].se > a[pos].se) continue;
		if(!vis[j]) dfs(j);
		for(int t = 0; t <= k; t++){
			int det = a[pos].fi - a[j].fi + a[pos].se - a[j].se - 1;
			if(t + det > k) break;
			dp[pos][t + det] = max(dp[pos][t + det], dp[j][t] + det + 1);
			res = max(res, dp[pos][t + det] + (k - t - det));
		}
	}
}
int main(){
	ios::sync_with_stdio(false);
	cin >> n >> k;
	for(int i = 1; i <= n; i++){
		cin >> a[i].fi >> a[i].se;
	}
	for(int i = 1; i <= n; i++){
		if(vis[i]) continue;
		dfs(i);
	}
	cout << res;
	return 0;
}