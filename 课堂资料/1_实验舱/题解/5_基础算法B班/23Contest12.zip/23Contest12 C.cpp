#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef long long ll;
typedef pair<ll,ll> pii;
const ll maxn = 210;
const ll INF = 2147483647;
const ll mod = 998244353;
ll n, m, res, a[maxn][maxn], pre[maxn][maxn];
int main(){
	ios::sync_with_stdio(false);
	cin >> n >> m;
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			cin >> a[i][j];
			a[i + n][j] = a[i + n][j + m] = a[i][j + m] = a[i][j];
		}
	}
	res = -INF;
	for(int j = 1; j <= m * 2; j++){
		for(int i = 1; i <= n * 2; i++){
			pre[j][i] = pre[j][i - 1] + a[i][j];
		}
	}
	for(int i = 1; i <= 2 * n; i++){
		for(int j = i; j < i + n; j++){
			if(j > 2 * n) break;
			for(int k = 1; k <= 2 * m; k++){
				ll tmp = 0;
				for(int l = k; l < k + m; l++){
					if(l > 2 * m) break;
					tmp += pre[l][j] - pre[l][i - 1];
					res = max(res, tmp);
				}
			}
		}
	}
	cout << res;
	return 0;
}