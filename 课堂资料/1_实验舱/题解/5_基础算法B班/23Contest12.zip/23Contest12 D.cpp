#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
#define fi first
#define se second
typedef long long ll;
typedef pair<ll,ll> pii;
const ll maxn = 200010;
const ll INF = 2147483647;
const ll mod = 998244353;
int n, res1, res2, res3, a[maxn], val[maxn], cnt[maxn], maxx[maxn];
int dp[maxn];
int main(){
	ios::sync_with_stdio(false);
	cin >> n;
	for(int i = 1; i <= n; i++) cin >> a[i];
	memset(dp, 0x3f, sizeof(dp));
	dp[0] = 0;
	for(int i = 1; i <= n; i++){
		int l = 0, r = n + 1;
		while(l < r - 1){
			int mid = (l + r) >> 1;
			if(dp[mid] < a[i]) l = mid;
			else r = mid;
		}
		dp[l + 1] = a[i];
		val[i] = l + 1;
		res1 = max(res1, l + 1);
	}
	for(int i = n; i >= 1; i--){
		if(val[i] == res1 || a[i] < maxx[val[i] + 1]){
			cnt[val[i]]++;
			maxx[val[i]] = max(maxx[val[i]], a[i]);
			res2++;
		}
	}
	for(int i = 1; i <= res1; i++) res3 += cnt[i] == 1;
	cout << res1 << " " << res2 << " " << res3 << "\n";
	return 0;
}