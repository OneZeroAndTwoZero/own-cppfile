#include <bits/stdc++.h>
#define N 200005
using namespace std;
typedef long long ll;

template <typename T>
inline void read(T &num) {
	T x = 0, f = 1; char ch = getchar();
	for (; ch > '9' || ch < '0'; ch = getchar()) if (ch == '-') f = -1;
	for (; ch <= '9' && ch >= '0'; ch = getchar()) x = (x<<3)+(x<<1)+(ch^'0');
	num = x * f;
}

int n, Q, a[N]; 
ll s[20][2];

int main() {
	read(n);
	for (int i = 1; i <= n; i++) {
		read(a[i]);
		for (int j = 0; j < 20; j++) s[j][i>>j&1] += a[i];
	}
	ll ans = 0;
	for (int i = 0; i < 20; i++) ans += 2*s[i][0]*s[i][1];
	printf("%lld\n", ans);
	read(Q); 
	while (Q--) {
		int x, y; read(x); read(y);
		int diff = y-a[x]; a[x] = y;
		for (int i = 0; i < 20; i++) s[i][x>>i&1] += diff;
		ans = 0;
		for (int i = 0; i < 20; i++) ans += 2*s[i][0]*s[i][1];
		printf("%lld\n", ans);
	}
	return 0;
} 
