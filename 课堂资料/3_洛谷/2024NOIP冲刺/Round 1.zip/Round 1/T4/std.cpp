#include <bits/stdc++.h>
#define N 800005
#define M 2000005
#define fi first
#define se second
#define pb push_back 
using namespace std;

char buf[1<<23], *p1, *p2;
#define getchar() p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<23,stdin),p1==p2)?EOF:*p1++ 
template <typename T>
inline void read(T &num) {
	T x = 0, f = 1; char ch = getchar();
	for (; ch > '9' || ch < '0'; ch = getchar()) if (ch == '-') f = -1;
	for (; ch <= '9' && ch >= '0'; ch = getchar()) x = (x<<3)+(x<<1)+(ch^'0');
	num = x * f;
}
char obuf[1<<23], *op=obuf;
#define putchar(c) *op++=c 
template <typename T>
void write(T num) {
	if (num < 0) putchar('-'), num = -num;
	if (num >= 10) write(num/10);
	putchar(num%10+'0');
}

int n, m, c[N], s[N], h[M];
vector<int> E[N];
int dfn[N], out[N], cc;
int id[N], tme[N], col[N];
int up[M], Fa[N], cnt[N];
int v1[N], v2[N];
pair<int,int> FFa[N]; 

void dfs(int x, int fa) {
	dfn[x] = ++cc; id[cc] = x;
	for (auto y : E[x]) if (y != fa) {
		Fa[y] = x; dfs(y, x);
	}
	out[x] = cc;
}

int tr[N];
inline void upd(int x, int v) { for(;x<=n;x+=x&-x)tr[x]+=v; }
inline int qry(int x) { int r=0;for(;x;x-=x&-x)r+=tr[x];return r;}

pair<int,int> Add[N], Del[N];
int tot; 

void dfs2(int x, int fa) {
	int mem = col[s[x]]; 
	if (max(1,mem) <= tme[x]) {
		Add[++tot] = {max(1,mem),x};
		Del[tot] = {tme[x],x};
	}
	col[s[x]] = max(col[s[x]], tme[x]+1);
	for (auto y : E[x]) if (y != fa) dfs2(y, x);
	col[s[x]] = mem;
}

void solve(int l, int r, int x, int y) {
	if (x > y) return;
	if (l == r) {
		for (int i = x; i <= y; i++) tme[id[i]] = l;
		return;
	}
	int mid = (l+r)>>1;
	for (int i = x; i <= y; i++) cnt[id[i]] = 0;
	for (int i = l; i <= mid; i++) ++cnt[up[i]];
	for (int i = y; i >= x; i--) cnt[Fa[id[i]]] += cnt[id[i]];
	auto ok = [&](int u) { return cnt[u]<c[u]; };
	for (int i = x; i <= y; i++) {
		if (ok(Fa[id[i]])) {
			FFa[id[i]] = {Fa[id[i]], FFa[Fa[id[i]]].second};
		} else {
			FFa[id[i]] = {FFa[Fa[id[i]]].first, Fa[id[i]]};
		}
	}
	for (int i = l; i <= mid; i++) {
		if (ok(up[i])) up[i] = FFa[up[i]].second;
	}
	for (int i = mid+1; i <= r; i++) {
		if (!ok(up[i])) up[i] = FFa[up[i]].first;
	}
	int c1 = 0, c2 = 0;
	for (int i = x; i <= y; i++) {
		int u = id[i];
		if (!ok(u)) v1[++c1] = u, Fa[u] = FFa[u].second;
		else v2[++c2] = u, Fa[u] = FFa[u].first, c[u] -= cnt[u];
	}
	int nw = x;
	for (int i = 1; i <= c1; i++) id[nw++] = v1[i];
	for (int i = 1; i <= c2; i++) id[nw++] = v2[i];
	solve(l, mid, x, x+c1-1); 
	solve(mid+1, r, x+c1, y); 
}

int main() {
//	cout << (&_ - &__)/1000000;
//	freopen("data\\21.in", "r", stdin);
//	freopen("my.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; i++) read(c[i]);
	for (int i = 1; i <= n; i++) read(s[i]);
	for (int i = 1; i <= m; i++) read(h[i]);
	for (int i = 1, u, v; i < n; i++) {
		read(u); read(v);
		E[u].pb(v); E[v].pb(u);
	}
	dfs(1, 0);
	for (int i = 1; i <= m; i++) up[i] = h[i];
	solve(0, m+1, 1, n);
	dfs2(1, 0);
	memset(tr, 0, sizeof(tr));
	sort(Add+1, Add+tot+1);
	sort(Del+1, Del+tot+1);
	int p = 1, q = 1; 
	for (int i = 1; i <= m; i++) {
		while (p <= tot && Add[p].fi == i) {
			int x = Add[p++].se;
			upd(dfn[x], 1); upd(out[x]+1, -1);	
		}
		write(qry(dfn[h[i]])); putchar(' ');
		while (q <= tot && Del[q].fi == i) {
			int x = Del[q++].se;
			upd(dfn[x], -1); upd(out[x]+1, 1);	
		}
	}
	fwrite(obuf,1,op-obuf,stdout);
	return 0;
} 
