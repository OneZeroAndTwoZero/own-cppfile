#include <bits/stdc++.h>
#define N 2005
#define fi first
#define se second
using namespace std;

char s[N]; 
int n, m, nxt[N];
int dp[N][N], to[N][30], dep[N];

int main() {
	scanf("%s %d", s+1, &m); n = strlen(s+1);
	dep[1] = 1;
	for (int i = 2, j = 0; i <= n; i++) {
		while (j && s[i] != s[j+1]) j = nxt[j];
		if (s[i] == s[j+1]) ++j;
		nxt[i] = j; dep[i] = dep[j]+1;
	} 
	for (int i = 0; i <= n; i++) {
		for (int c = 0; c < 26; c++) {
			int j = i;
			while (j && c != s[j+1]-'a') j = nxt[j]; 
			if (c == s[j+1]-'a') ++j;
			to[i][c] = j;
		}
	}
	memset(dp, -0x3f, sizeof(dp));
	dp[0][0] = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j <= n; j++) {
			for (int c = 0; c < 26; c++) {
				dp[i+1][to[j][c]] = max(dp[i+1][to[j][c]], dp[i][j]+dep[to[j][c]]);
			}
		} 
	}
	int ans = 0;
	for (int i = 0; i <= n; i++) {
		ans = max(ans, dp[m][i]);
	}
	printf("%d\n", ans);
	return 0;
} 
