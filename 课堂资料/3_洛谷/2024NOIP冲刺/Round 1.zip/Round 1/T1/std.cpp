#include <bits/stdc++.h>
#define N 1000005
using namespace std;

template <typename T>
inline void read(T &num) {
	T x = 0, f = 1; char ch = getchar();
	for (; ch > '9' || ch < '0'; ch = getchar()) if (ch == '-') f = -1;
	for (; ch <= '9' && ch >= '0'; ch = getchar()) x = (x<<3)+(x<<1)+(ch^'0');
	num = x * f;
}

int n, m, k;
int l[N], r[N], t[N];

int main() {
	read(n); read(m); read(k);
	for (int i = 1; i <= m; i++) {
		read(l[i]); read(r[i]); read(t[i]);
	}
	for (int i = m; i; i--) {
		if (t[i]) {
			if (k >= n-r[i]+l[i]) k = k-n+r[i];
			else if (k >= l[i]) k = k-l[i]+r[i]+1;
		} else {
			if (k <= r[i]-l[i]+1) k = k-1+l[i];
			else if (k <= r[i]) k = k-r[i]+l[i]-1;
		}
	}
	printf("%d\n", k);
	return 0;
} 
