#include <cstdio>
#include <vector>
#include <queue>

using namespace std;

const int MAXN = 3e3 + 5;

bool bio[MAXN], bio_edge[MAXN][MAXN];

int n;
int colors[MAXN][MAXN], sol[MAXN], dad[MAXN], dist[MAXN];

vector<vector<int>> one_comp;
vector<int> tree[MAXN];

void find_component(int start, int node, vector<int> *oc)
{
  if (colors[start][node] != 1)
    return;
  bio[node] = true;
  oc->push_back(node);
  for (int next = 0; next < n; ++next)
    if (!bio[next])
      find_component(start, next, oc);
}

void generate_tree()
{
  for (int i = 0; i < n; ++i)
  {
    if (bio[i])
      continue;
    one_comp.push_back({});
    find_component(i, i, &one_comp.back());
  }

  vector<int> pivots;
  for (const auto &comp : one_comp)
  {
    pivots.emplace_back(comp[0]);
    for (int x : comp)
    {
      if (x != comp[0])
      {
        tree[x].emplace_back(comp[0]);
        tree[comp[0]].emplace_back(x);
      }
    }
  }

  for (int i = 0; i < (int)pivots.size(); ++i)
  {
    for (int j = i + 1; j < (int)pivots.size(); ++j)
    {
      int ii = pivots[i], jj = pivots[j];
      if (bio_edge[ii][jj] || colors[ii][jj] != 2)
        continue;
      vector<int> comp = {ii, jj};
      for (int k = j + 1; k < (int)pivots.size(); ++k)
      {
        int kk = pivots[k];
        if (colors[ii][kk] != 2 || colors[jj][kk] != 2)
          continue;
        comp.emplace_back(kk);
      }
      for (int k = 0; k < (int)comp.size(); ++k)
      {
        if (k > 0)
        {
          tree[comp[k]].push_back(comp[0]);
          tree[comp[0]].push_back(comp[k]);
        }
        for (int l = k + 1; l < (int)comp.size(); ++l)
        {
          int kk = comp[k], ll = comp[l];
          bio_edge[kk][ll] = bio_edge[ll][kk] = true;
        }
      }
    }
  }
}

void color_tree()
{
  int max_col = 0;
  dist[0] = 0;
  dad[0] = -1;
  sol[0] = ++max_col;
  queue<int> Q;
  Q.push(0);
  while (!Q.empty())
  {
    int node = Q.front();
    Q.pop();
    for (int nxt : tree[node])
    {
      if (sol[nxt] != 0)
        continue;
      dad[nxt] = node;
      dist[nxt] = dist[node] + 1;
      int curr = node;
      while (curr != -1 && colors[curr][node] != colors[curr][nxt])
        curr = dad[curr];
      if (curr != -1)
      {
        sol[nxt] = sol[curr];
      }
      else
      {
        int min_dist = n + 1;
        for (int i = 0; i < n; ++i)
        {
          if (sol[i] && colors[i][node] == colors[i][nxt] &&
              min_dist > dist[i])
          {
            min_dist = dist[i];
            sol[nxt] = sol[i];
          }
        }
      }
      if (!sol[nxt])
        sol[nxt] = ++max_col;
      Q.push(nxt);
    }
  }
}

int main(void)
{
  freopen("tree.in", "r", stdin);
  freopen("tree.out", "w", stdout);
  int subtask;
  scanf("%d%d", &subtask, &n);
  for (int i = 0; i < n; ++i)
    for (int j = 0; j < n; ++j)
      scanf("%d", &colors[i][j]);

  generate_tree();
  color_tree();

  for (int i = 0; i < n; ++i)
    printf("%d ", sol[i]);
  printf("\n");
  for (int i = 0; i < n; ++i)
    for (int j : tree[i])
      if (i < j)
        printf("%d %d\n", i + 1, j + 1);

  return 0;
}

