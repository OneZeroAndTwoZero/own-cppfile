#include <bits/stdc++.h>
using namespace std;
const int N = 2005, M = 5e6, dx[] = {1, 1, 0}, dy[] = {0, 1, 1};
int n, m, cnt, ans = 1, op[M], fa[M], id[M];
string s[N];
int getf(int x)
{
    return fa[x] == x ? x : fa[x] = getf(fa[x]);
}
int main()
{
    freopen("grid.in", "r", stdin);
    freopen("grid.out", "w", stdout);

    cin.tie(0)->sync_with_stdio(0);
    cin >> n >> m;
    for (int i = 0; i < n; i++)
        cin >> s[i];
    iota(fa, fa + n * m, 0);
    queue<array<int, 2>> q;
    for (int x = 0; x < n; x++)
        for (int y = 0; y < m; y++)
            if (s[x][y] == '#')
                q.push({x, y});
    auto upd = [&](int x, int y) {
        if (s[x][y] == '.')
            s[x][y] = '#', q.push({x, y});
    };
    auto chk = [&](int x, int y) {
        if (x < 0 || y < 0 || x > n - 2 || y > m - 2)
            return;
        if (s[x + 1][y] == '#' && s[x][y + 1] == '#')
            upd(x, y), upd(x + 1, y + 1);
    };
    while (!q.empty())
    {
        auto t = q.front();
        q.pop();
        int x = t[0], y = t[1];
        if (!x && y < m - 1)
            upd(x, y + 1);
        if (!y && x < n - 1)
            upd(x + 1, y);
        if (x == n - 1 && y)
            upd(x, y - 1);
        if (y == m - 1 && x)
            upd(x - 1, y);
        chk(x - 1, y);
        chk(x, y - 1);
    }
    for (int x = 0; x < n; x++)
        for (int y = 0; y < m; y++)
            if (s[x][y] == '#')
                for (int o : {0, 1, 2})
                {
                    int nx = x + dx[o], ny = y + dy[o];
                    if (nx < 0 || ny < 0 || nx >= n || ny >= m ||
                        s[nx][ny] == '.')
                        continue;
                    int u = getf(x * m + y), v = getf(nx * m + ny);
                    if (u != v)
                        fa[u] = v;
                }
    for (int x = 0; x < n; x++)
        for (int y = 0; y < m; y++)
            if (s[x][y] == '#')
            {
                int u = getf(x * m + y), &p = id[u];
                if (!p)
                    p = ++cnt;
                if (!x || y == m - 1)
                    op[p] |= 1;
                if (!y || x == n - 1)
                    op[p] |= 2;
            }
    for (int i = 1; i <= cnt; i++)
    {
        ans++;
        if (op[i] == 3)
        {
            cout << 0;
            return 0;
        }
        if (op[i])
            ans--;
    }
    cout << ans;
    return 0;
}

