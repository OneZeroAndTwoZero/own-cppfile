#include<bits/stdc++.h>
using namespace std;

int main() {
	freopen("a.in", "r", stdin);
	freopen("b.out", "w", stdout);
	int a, b;
	scanf("%d %d", &a, &b);
	printf("%d\n", a + b);
	return 0;
}
